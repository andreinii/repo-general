﻿namespace proyecto_1
{
    internal class Program
    {
        static void Main(string[] args)
        {

           
            Boligrafo boligrafoAzul = new Boligrafo("Azul", "fino");
            Boligrafo boligrafoRojo = new Boligrafo("Rojo", "grueso");

           
            Console.WriteLine("boligrafo azul:");
            Console.WriteLine(boligrafoAzul.escribir("Hola"));
            Console.WriteLine("Tinta restante: " + boligrafoAzul.obtenerCantidadTinta());

            Console.WriteLine();

            Console.WriteLine("boligrafo rojo:");
            Console.WriteLine(boligrafoRojo.escribir("Hola"));
            Console.WriteLine("tinta restante: " + boligrafoRojo.obtenerCantidadTinta());

            Console.WriteLine();

      
            Console.WriteLine("se esta recargando boligrafo azul");
            Console.WriteLine(boligrafoAzul.recargar(10));
            Console.WriteLine("tinta  actual: " + boligrafoAzul.obtenerCantidadTinta());

            Console.WriteLine();

            Console.WriteLine("se esta recargando boligrafo rojo");
            Console.WriteLine(boligrafoRojo.recargar(50));
            Console.WriteLine("tinta actual: " + boligrafoRojo.obtenerCantidadTinta());


            Console.WriteLine("usaste los colores:" + boligrafoAzul.obtenerColor() + " " + boligrafoRojo.obtenerColor());      // quiero ver si se paso bien el parametro

        }
    }
}
