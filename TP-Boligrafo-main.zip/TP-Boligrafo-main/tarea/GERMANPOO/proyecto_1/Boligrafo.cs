﻿using System;
using System.Collections.Generic;
using System.Text;

namespace proyecto_1
{
    public class Boligrafo
    {

        private int capacidaddetintamaxima;
        private string grosorpunta;
        private string color;
        private int cantidadtinta;


        public Boligrafo(string color, string grosorpunta)
        {
            capacidaddetintamaxima = 100;
            cantidadtinta = 80;
            this.color = color;
            this.grosorpunta = grosorpunta;
        }

        public string escribir(string texto)
        {
            int suficientetinta = texto.Length;

            if (grosorpunta == "grueso")
            {
                suficientetinta = suficientetinta * 2;
            }

            if (cantidadtinta >= suficientetinta)
            {
                cantidadtinta = cantidadtinta - suficientetinta;
                return texto;
            }
            else
            {
                return "No alcanza la tinta.";
            }




        }

        public string recargar(int cantidadrecargar)
        {
            int tintaNueva = cantidadtinta + cantidadrecargar;

            if (tintaNueva <= capacidaddetintamaxima)
            {
                cantidadtinta = tintaNueva;
                return "lapicera recargada";
            }
            else
            {
                int sobrante = tintaNueva - capacidaddetintamaxima;
                cantidadtinta = capacidaddetintamaxima;

                return "se recargo la lapicera y sobro " + sobrante + " cantidad de tinta.";
            }
        }
        public int obtenerCantidadTinta()
        {
            return cantidadtinta;
        }

        public string obtenerColor()
        {
            return color;
        }
    }
}
