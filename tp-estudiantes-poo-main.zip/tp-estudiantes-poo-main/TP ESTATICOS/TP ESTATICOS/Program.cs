﻿namespace TP_ESTATICOS
{
    using ESTUDIANTES;
    internal class Program
    {
        static void Main(string[] args)
        {
            Estudiante estudiante1 = new Estudiante("lala", "lele", "1");

            estudiante1.SetNotaPrimerParcial(8);

            estudiante1.SetNotaSegundoParcial(7);


            Console.WriteLine(estudiante1.Mostrar());


            Estudiante estudiante2 = new Estudiante("baba", "bebe", "2");

            estudiante2.SetNotaPrimerParcial(6); 
            
            estudiante2.SetNotaSegundoParcial(9);

            Console.WriteLine(estudiante2.Mostrar());

            Estudiante estudiante3 = new Estudiante("sasa", "sese", "3");

            estudiante3.SetNotaPrimerParcial(3);
            
            estudiante3.SetNotaSegundoParcial(8);

            Console.WriteLine(estudiante3.Mostrar());


            Console.WriteLine("cantidad de estudiantes: " + Estudiante.ObtenerCantidadEstudiantes());

            Estudiante.ReiniciarContador();

            Console.WriteLine("cantidad despues de reiniciar: " + Estudiante.ObtenerCantidadEstudiantes());

        }
    }
}
