﻿using System.Text;

namespace ESTUDIANTES
{
    public class Estudiante
    {
       
        public string nombre;
        public string apellido;
        public string legajo;
        public int notaPrimerParcial;
        public int notaSegundoParcial;
        public static Random random;
        public static int cantidadEstudiantes;

       
        static Estudiante()
        {
            random = new Random();
            cantidadEstudiantes = 0;
        }

       
        public Estudiante(string nombre, string apellido, string legajo)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.legajo = legajo;

            cantidadEstudiantes = cantidadEstudiantes + 1; //contador
        }

        

        public void SetNotaPrimerParcial(int nota)
        {
            notaPrimerParcial = nota;
        }

        public void SetNotaSegundoParcial(int nota)
        {
            notaSegundoParcial = nota;
        }

        private float CalcularPromedio()
        {
            return (notaPrimerParcial + notaSegundoParcial) / 2;
        }

        public double CalcularNotaFinal()
        {
            if (notaPrimerParcial < 4 || notaSegundoParcial < 4)
            {
                return -1;
            }
            return random.Next(6, 11);

           
        }
        public static int ObtenerCantidadEstudiantes()
        {
            return cantidadEstudiantes;
        }

        public string Mostrar()
        {
            StringBuilder info = new StringBuilder();

            info.AppendLine($"Nombre: {nombre}");
            info.AppendLine($"Apellido: {apellido}");
            info.AppendLine($"Legajo: {legajo}");
            info.AppendLine($"Nota primer parcial: {notaPrimerParcial}");
            info.AppendLine($"Nota segundo parcial: {notaSegundoParcial}");
            info.AppendLine($"Promedio: {CalcularPromedio()}");

            double notaFinal = CalcularNotaFinal();

            if (notaFinal != -1)
            {
                info.AppendLine($"Nota final: {notaFinal}");
            }
            else
            {
                info.AppendLine("Alumno desaprobado");
            }

            return info.ToString();
        }


  
        public static void ReiniciarContador()
        {
            cantidadEstudiantes = 0;
        }
    }
}