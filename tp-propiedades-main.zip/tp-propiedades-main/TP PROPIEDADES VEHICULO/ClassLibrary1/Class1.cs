﻿using System.Text;

namespace ClassLibrary1
{
    public enum TipoVehiculo
    {
        Auto,
        Utilitario,
        SUV,
        Premium
    }


    public class Vehiculo
    {
        private string patente;

        public string Patente
        {
            get
            {
                if (string.IsNullOrWhiteSpace(patente))
                {
                    Console.WriteLine("El vehículo no tiene patente.");
                }

                return patente;
            }
            set
            {
                Console.WriteLine("Se está modificando la patente");
                if (ValidarPatente(value))
                {
                    patente = value;
                }
            }
        }

        bool ValidarPatente(string patente)
        {
            if (string.IsNullOrWhiteSpace(patente))
            {
                return false;
            }

            if (patente.Length < 6 || patente.Length > 7)
            {
                return false;
            }

            return true;
        }


        private double _precioBase; //el atributo privado

        public double PrecioBase
        {
            set
            {
                if (value > 0)
                {
                    _precioBase = value; //ESTE SE ALMACENA ARRIBA PERO NO LO PODES LLAMAR DESDE MAIN
                    Console.WriteLine("todo ok");
                }
                else
                {
                    Console.WriteLine("cero o negativo");
                }
            }





        }

        public string Marca { get; set; }
        public string Modelo { get; set; }

        public int Kilometraje
        {
            get;

            private set;
        }



       
        public void modificarkilometraje(int kilometros)
        {
            if (kilometros > 0)
            {
                Kilometraje += kilometros;
            }
            else
            {
                Console.WriteLine("Los kilómetros deben ser mayores que cero.");
            }
        }







        private int _añoFabricacion;

        public int AñoFabricacion
        {
            get
            {
                return _añoFabricacion;
            }
            set
            {
                if (value >= 1960 && value <= DateTime.Now.Year)
                {
                    _añoFabricacion = value;
                }
            }
        }


        public enum TipoVehiculo
        {
            Auto,
            Utilitario,
            SUV,
            Premium
        }


        public TipoVehiculo Tipo { get; set; }

        public int Antiguedad
        {
            get
            {
                return DateTime.Now.Year - AñoFabricacion;
            }
        }



        public double PrecioFinal
        {
            get
            {
                if (Tipo == TipoVehiculo.Auto) //0 %
                {
                    Console.WriteLine("se aplico 0%");
                    return _precioBase;

                }

                if (Tipo == TipoVehiculo.Utilitario) //10 %
                {
                    Console.WriteLine("se aplico 10%");
                    return _precioBase * 1.10;

                }

                if (Tipo == TipoVehiculo.SUV) //20 %
                {
                    Console.WriteLine("se aplico 20%");
                    return _precioBase * 1.20;

                }

                if (Tipo == TipoVehiculo.Premium) //35 %
                {
                    Console.WriteLine("se aplico 35%");
                    return _precioBase * 1.35;

                }

                return _precioBase;


            }


        }

        public Vehiculo(string patente, double precioBase, string marca, string modelo, int kilometraje, int añoFabricacion, TipoVehiculo tipo)
        {
            this.Patente = patente;
            this.PrecioBase = precioBase;
            this.Marca = marca;
            this.Modelo = modelo;
            this.modificarkilometraje(kilometraje);
            this.AñoFabricacion = añoFabricacion;
            this.Tipo = tipo;
        }

        //esto ya lo tenia no habia llegado a este punto
        public string ObtenerDescripcionTipo()
        {
            switch (Tipo)
            {
                case TipoVehiculo.Auto:
                    return "Vehiculo auto";

                case TipoVehiculo.Utilitario:
                    return "Vehiculo utilitario";

                case TipoVehiculo.SUV:
                    return "Vehiculo suv";

                case TipoVehiculo.Premium:
                    return "Vehiculo premium";

                default:
                    return "algo no funciono";
            }
        }
        public string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("patente: " + Patente);
            sb.AppendLine("marca: " + Marca);
            sb.AppendLine("modelo: " + Modelo);
            sb.AppendLine("Año de fabricacion: " + AñoFabricacion);
            sb.AppendLine("Antiguedad: " + Antiguedad);
            sb.AppendLine("kilometraje: " + Kilometraje);
            sb.AppendLine("Tipo de vehiculo: " + Tipo);
            sb.AppendLine("Descripcion: " + ObtenerDescripcionTipo());
            sb.AppendLine("precio final : " + PrecioFinal);

            return sb.ToString();
        }

    }




}
