﻿using ClassLibrary1;

namespace TP_PROPIEDADES_VEHICULO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Vehiculo vehiculo = new Vehiculo("ABC123", 5000, "Renault", "19", 50000, 2020, Vehiculo.TipoVehiculo.Auto);

            Console.WriteLine(vehiculo.Patente);
            //PRUEBAS
            //vehiculo.PrecioBase = 5000;
            //vehiculo.PrecioBase = -1000;
            //vehiculo.PrecioBase = 0;



            Console.WriteLine(vehiculo.Marca);

            

            Console.WriteLine(vehiculo.Modelo);



            vehiculo.modificarkilometraje(350);

            Console.WriteLine(vehiculo.Kilometraje);

            //vehiculo.AñoFabricacion = 2020;


            Console.WriteLine(vehiculo.Antiguedad);


            Console.WriteLine(vehiculo.PrecioFinal);


        }






    }
}
