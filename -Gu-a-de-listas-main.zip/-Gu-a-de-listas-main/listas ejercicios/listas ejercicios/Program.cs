﻿namespace listas_ejercicios
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");


            List<string> listadeinvitados = new List<string>();

            listadeinvitados.Add("pepe");
            listadeinvitados.Add("fulano");
            listadeinvitados.Add("agustin");
            listadeinvitados.Add("");

            foreach (string invitado in listadeinvitados)
            {
                Console.WriteLine(invitado);
            }



            List<string> materias = new List<string>();

            materias.Add("poo");
            materias.Add("python");
            materias.Add("ingles");
            materias.Add("bd");
            materias.Add("matematicas");

            Console.WriteLine("El estudiante tiene " + materias.Count + " materias cargadas.");

            List<string> comercio = new List<string>();

            comercio.Add("Mouse");
            comercio.Add("Teclado");
            comercio.Add("Monitor");
            comercio.Add("Auriculares");

            Console.WriteLine("Ingrese un producto:");
            string producto = Console.ReadLine();

            int posicion = comercio.IndexOf(producto);

            if (comercio.Contains(producto) == true)
            {
                Console.WriteLine("existe en la lista");
                Console.WriteLine("la posicion es : " + posicion);
            }
            else
            {
                Console.WriteLine("no existe en la lista ");
            }



            List<string> materias2 = new List<string>();

            materias.Add("programacion");
            materias.Add("matematicas");
            materias.Add("ingles");
            materias.Add("bd");

            materias.Remove("Inglés");

            for (int i = 0; i < materias.Count; i++)
            {
                Console.WriteLine(materias[i]);
            }


            List<string> ciudades = new List<string>();

            ciudades.Add("Buenos Aires");
            ciudades.Add("Cordoba");
            ciudades.Add("Rosario");
            ciudades.Add("Mendoza");
            ciudades.Add("Salta");

            Console.WriteLine("antes:");

            for (int i = 0; i < ciudades.Count; i++)
            {
                Console.WriteLine(ciudades[i]);
            }

            ciudades.RemoveAt(2);

            Console.WriteLine("despues:");

            for (int i = 0; i < ciudades.Count; i++)
            {
                Console.WriteLine(ciudades[i]);
            }





            List<string> diaslaborales = new List<string>();
            diaslaborales.Add("lunes");
            diaslaborales.Add("martes");
            diaslaborales.Add("jueves");
            diaslaborales.Add("viernes");
            diaslaborales.Insert(2, "Miércoles");




            List<string> concesionaria = new List<string>();

            concesionaria.Add("Ford");
            concesionaria.Add("Toyota");
            concesionaria.Add("Fiat");
            concesionaria.Add("Chevrolet");
            concesionaria.Add("Volkswagen");

            int posicion2 = concesionaria.IndexOf("Fiat");

            Console.WriteLine("fiat esta en: " + posicion2);


            List<int> precios = new List<int>();

            precios.Add(2500);
            precios.Add(800);
            precios.Add(1200);
            precios.Add(5000);
            precios.Add(1750);

            precios.Sort();

            for (int i = 0; i < precios.Count; i++)
            {
                Console.WriteLine(precios[i]);
            }

            List<string> participantes = new List<string>
             {"Ana","Pedro", "Juan", "lucía","Carlos" }; //menos lineas

            participantes.Reverse();

            for (int i = 0; i < participantes.Count; i++)
            {
                Console.WriteLine(participantes[i]);
            }

            List<string> listacompras = new List<string>
            {
                "Pan",
                "Leche",
                "Arroz",
                "Fideos",
                "Huevos"
            };

            Console.WriteLine("cant de productos: " + listacompras.Count);

            listacompras.Clear();

            Console.WriteLine("cant de productos: " + listacompras.Count);


            List<int> notas = new List<int>
            {
                3,
                4,
                7,
                5,
                8,
                9
            };

            List<int> aprobados = new List<int>();

            for (int i = 0; i < notas.Count; i++)
            {
                if (notas[i] >= 6)
                {
                    Console.WriteLine("nota aprobada: " + notas[i]);
                    aprobados.Add(notas[i]);
                    break;

                }
            }





            for (int i = 0; i < aprobados.Count; i++)
            {
                Console.WriteLine(aprobados[i]);
            }



            List<int> stock = new List<int>
                {
                    10,
                    0,
                    4,
                    0,
                    8,
                    3,
                    0,
                    15
                };

            for (int i = stock.Count - 1; i >= 0; i--)  //desde el final de la lista hasta el principio)
            {
                if (stock[i] >= 0)
                {
                    stock.RemoveAt(i);
                }
            }

            for (int i = 0; i < stock.Count; i++)
            {
                Console.WriteLine(stock[i]);
            }




            List<int> temperaturas = new List<int>();

            Console.WriteLine("temperatura dia 1:");
            temperaturas.Add(int.Parse(Console.ReadLine()));

            Console.WriteLine("temperatura dia 2:");
            temperaturas.Add(int.Parse(Console.ReadLine()));

            Console.WriteLine("temperatura dia 3:");
            temperaturas.Add(int.Parse(Console.ReadLine()));

            Console.WriteLine("temperatura dia 4:");
            temperaturas.Add(int.Parse(Console.ReadLine()));

            Console.WriteLine("temperatura dia 5:");
            temperaturas.Add(int.Parse(Console.ReadLine()));


            Console.WriteLine("temperaturas:");

            for (int i = 0; i < temperaturas.Count; i++)
            {
                Console.WriteLine(temperaturas[i]);
            }


            temperaturas.Sort();//LA MAS BAJA ES LA PRIMERA

            Console.WriteLine("Temperaturas ordenadas:");

            for (int i = 0; i < temperaturas.Count; i++)
            {
                Console.WriteLine(temperaturas[i]);
            }

            //comparaciones
            int minimo = temperaturas[0];
            int maximo = temperaturas[0];

            for (int i = 0; i < temperaturas.Count; i++)
            {
                if (temperaturas[i] < minimo)
                {
                    minimo = temperaturas[i];
                }

                if (temperaturas[i] > maximo)
                {
                    maximo = temperaturas[i];
                }
            }

            Console.WriteLine("la mas baja es: " + minimo);
            Console.WriteLine("la mas alta es: " + maximo);

            //punto gigante 

            List<string> SISTEMADEALUMNOS = new List<string>();

            int opcion = -1; //PARA ROMPER BULCE 

            while (opcion != 0)
            {
                Console.WriteLine("SISTEMA DE ALUMNOS");
                Console.WriteLine("/////////////////////");
                Console.WriteLine("1 - Agregar alumno");
                Console.WriteLine("2 - Mostrar alumnos");
                Console.WriteLine("3 - Buscar alumno");
                Console.WriteLine("4 - Eliminar alumno");
                Console.WriteLine("5 - Ordenar alumnos");
                Console.WriteLine("6 - Mostrar cantidad de alumnos");
                Console.WriteLine("7 - Eliminar todos los alumnos");
                Console.WriteLine("0 - Salir");
                Console.WriteLine("/////////////////////");

                Console.WriteLine("Ingrese una opcion:");
                opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("nombre?");
                        string alumno = Console.ReadLine();

                        SISTEMADEALUMNOS.Add(alumno);
                        break;

                    case 2:
                        for (int i = 0; i < SISTEMADEALUMNOS.Count; i++)
                        {
                            Console.WriteLine(SISTEMADEALUMNOS[i]);
                        }
                        break;

                    case 3:
                        Console.WriteLine("nombre?");
                        string ALUMABUSCAR = Console.ReadLine();

                        if (SISTEMADEALUMNOS.Contains(ALUMABUSCAR))
                        {
                            Console.WriteLine("El alumno existe");
                        }
                        else
                        {
                            Console.WriteLine("El alumno no existe");
                        }
                        break;

                    case 4:
                        Console.WriteLine("Ingrese el nombre del alumno a eliminar:");
                        string ALUMAELIMINAR = Console.ReadLine();

                        SISTEMADEALUMNOS.Remove(ALUMAELIMINAR);
                        break;

                    case 5:
                        SISTEMADEALUMNOS.Sort();
                        Console.WriteLine("Los alumnos fueron ordenados.");
                        break;

                    case 6:
                        Console.WriteLine(SISTEMADEALUMNOS.Count);
                        break;

                    case 7:
                        SISTEMADEALUMNOS.Clear();

                        Console.WriteLine("Se eliminaron todos los alumnos.");
                        break;

                    case 0:
                        break;

                    default:
                        Console.WriteLine("no es una opcion");
                        break;
                }
            }
        }
    }
}
